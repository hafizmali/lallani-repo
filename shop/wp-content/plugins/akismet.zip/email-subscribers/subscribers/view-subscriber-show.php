<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( !empty( $_POST ) && ! wp_verify_nonce( $_REQUEST['wp_create_nonce'], 'subscriber-nonce' ) ) {
	die('<p>Security check failed.</p>');
}

$es_c_email_subscribers_ver = get_option('email-subscribers');
if ( $es_c_email_subscribers_ver != "2.9" ) {
	?><div class="error fade">
		<p>
			Note: You have recently upgraded the plugin and your tables are not sync.
			Please <a title="Sync plugin tables." href="<?php echo ES_ADMINURL; ?>?page=es-settings&amp;ac=sync"><?php echo __( 'Click Here', 'email-subscribers' ); ?></a> to sync the table.
			This is mandatory and it will not affect your data.
		</p>
	</div><?php
}

// Form submitted, check the data
$search_group = isset($_POST['searchquery_group']) ? $_POST['searchquery_group'] : 'ALL';
$search_sts = isset($_POST['searchquery_sts']) ? $_POST['searchquery_sts'] : '';
$search_count = isset($_POST['searchquery_cnt']) ? $_POST['searchquery_cnt'] : '1';

if (isset($_POST['frm_es_display']) && $_POST['frm_es_display'] == 'yes') {
	$did = isset($_GET['did']) ? $_GET['did'] : '0';
	es_cls_security::es_check_number($did);

	$es_success = '';
	$es_success_msg = FALSE;

	if ( (isset($_POST['frm_es_bulkaction']) && $_POST['frm_es_bulkaction'] != 'delete') && ($_POST['frm_es_bulkaction'] != 'resend' && $_POST['frm_es_bulkaction'] != 'groupupdate') && ($_POST['frm_es_bulkaction'] != 'updatestatus') && ($_POST['frm_es_bulkaction'] != 'search_sts' && $_POST['frm_es_bulkaction'] != 'search_cnt') && ($_POST['frm_es_bulkaction'] != 'search_group') ) {

		//	Just security thingy that wordpress offers us
		check_admin_referer('es_form_show');

		// First check if ID exist with requested ID
		$result = es_cls_dbquery::es_view_subscriber_count($did);
		if ($result != '1') {
			?><div class="error fade">
				<p><strong>
					<?php echo __( 'Selected details does not exists.', 'email-subscribers' ); ?>
				</strong></p>
			</div><?php
		} else {
			// Form submitted, check the action
			if (isset($_GET['ac']) && $_GET['ac'] == 'del' && isset($_GET['did']) && $_GET['did'] != '') {
				//	Delete selected record from the table
				es_cls_dbquery::es_view_subscriber_delete($did);

				//	Set success message
				$es_success_msg = TRUE;
				$es_success = __( 'Record deleted.', 'email-subscribers' );
			}

			if (isset($_GET['ac']) && $_GET['ac'] == 'resend' && isset($_GET['did']) && $_GET['did'] != '') {
				$did = isset($_GET['did']) ? $_GET['did'] : '0';
				$es_c_optinoption = get_option( 'ig_es_optintype' );

				if( $es_c_optinoption != "Double Opt In" ) {
					?>
					<div class="error fade">
						<p><strong>
							<?php echo __( 'To send confirmation email, please change the Opt-in option to Double Opt In.', 'email-subscribers' ); ?>
						</strong></p>
					</div>
					<?php
				} else {
					es_cls_sendmail::es_prepare_optin("single", $did, $idlist = "");
					es_cls_dbquery::es_view_subscriber_upd_status("Unconfirmed", $did);
					$es_success_msg = TRUE;
					$es_success  = __( 'Confirmation emails resent successfully.', 'email-subscribers' );
				}
			}
		}
	} else {
		check_admin_referer('es_form_show');

		if (isset($_POST['frm_es_bulkaction']) && $_POST['frm_es_bulkaction'] == 'delete') {

			$chk_delete = isset($_POST['chk_delete']) ? $_POST['chk_delete'] : '';

			if(!empty($chk_delete)) {
				$count = count($chk_delete);
				for($i=0; $i<$count; $i++) {
					$del_id = $chk_delete[$i];
					es_cls_dbquery::es_view_subscriber_delete($del_id);
				}

				//	Set success message
				$es_success_msg = TRUE;
				$es_success = __( 'Record deleted.', 'email-subscribers' );
			} else {
				?>
				<div class="error fade is-dismissible">
					<p><strong>
						<?php echo __( 'No record was selected.', 'email-subscribers' ); ?>
					</strong></p>
				</div>
				<?php
			}
		} elseif (isset($_POST['frm_es_bulkaction']) && $_POST['frm_es_bulkaction'] == 'resend') {

			$chk_delete = isset($_POST['chk_delete']) ? $_POST['chk_delete'] : '';

			$es_c_optinoption = get_option( 'ig_es_optintype' );

			if( $es_c_optinoption != "Double Opt In" ) {
				?>
				<div class="error fade">
					<p><strong>
						<?php echo __( 'To send confirmation mail, please change the Opt-in option to Double Opt In.', 'email-subscribers' ); ?>
					</strong></p>
				</div>
				<?php
			} else {
				if(!empty($chk_delete)) {
					$count = count($chk_delete);
					$idlist = "";
					for($i = 0; $i<$count; $i++) {
						$del_id = $chk_delete[$i];
						if($i < 1) {
							$idlist = $del_id;
						} else {
							$idlist = $idlist . ", " . $del_id;
						}
					}
					es_cls_sendmail::es_prepare_optin("group", 0, $idlist);
					es_cls_dbquery::es_view_subscriber_upd_status("Unconfirmed", $idlist);
					$es_success_msg = TRUE;
					$es_success = __( 'Confirmation emails resent successfully.', 'email-subscribers' );
				} else {
					?>
					<div class="error fade">
						<p><strong>
							<?php echo __( 'No record was selected.', 'email-subscribers' ); ?>
						</strong></p>
					</div>
					<?php
				}
			}
		} elseif (isset($_POST['frm_es_bulkaction']) && $_POST['frm_es_bulkaction'] == 'groupupdate') {

			$chk_delete = isset($_POST['chk_delete']) ? $_POST['chk_delete'] : '';

			if(!empty($chk_delete)) {
				$es_email_group = isset($_POST['es_email_group']) ? $_POST['es_email_group'] : '';
				if ($es_email_group != "") {
					$count = count($chk_delete);
					$idlist = "";
					for($i = 0; $i < $count; $i++) {
						$del_id = $chk_delete[$i];
						if($i < 1) {
							$idlist = $del_id;
						} else {
							$idlist = $idlist . ", " . $del_id;
						}
					}
					es_cls_dbquery::es_view_subscriber_upd_group($es_email_group, $idlist);
					$es_success_msg = TRUE;
					$es_success = __( 'Subscribers Group updated.', 'email-subscribers' );
				} else {
					?>
					<div class="error fade">
						<p><strong>
							<?php echo __( 'Please select New group to update.', 'email-subscribers' ); ?>
						</strong></p>
					</div>
					<?php
				}
			} else {
				?>
				<div class="error fade">
					<p><strong>
						<?php echo __( 'No record was selected.', 'email-subscribers' ); ?>
					</strong></p>
				</div>
				<?php
			}
		} elseif (isset($_POST['frm_es_bulkaction']) && $_POST['frm_es_bulkaction'] == 'updatestatus') {

			$chk_delete = isset($_POST['chk_delete']) ? $_POST['chk_delete'] : '';

			if(!empty($chk_delete)) {
				$es_email_status = isset($_POST['es_update_status']) ? $_POST['es_update_status'] : '';
				if (!empty($es_email_status)) {
					$count = count($chk_delete);
					$idstatus = "";
					for ($i=0; $i < $count; $i++) {
						$update_id = $chk_delete[$i];
						if ($i < 1) {
							$idstatus = $update_id;
						} else {
							$idstatus = $idstatus . ", " . $update_id;
						}
					}
					// es_cls_dbquery::es_bulk_update_subscriber_status($es_email_status, $idstatus);
					es_cls_dbquery::es_view_subscriber_upd_status($es_email_status, $idstatus);
					$es_success_msg = TRUE;
					$es_success = __( 'Subscribers Status updated.', 'email-subscribers' );
				} else {
					?>
					<div class="error fade">
						<p><strong>
							<?php echo __( 'Please select New Status to update.', 'email-subscribers' ); ?>
						</strong></p>
					</div>
					<?php
				}
			} else {
				?>
				<div class="error fade is-dismissible">
					<p><strong>
						<?php echo __( 'No record was selected.', 'email-subscribers' ); ?>
					</strong></p>
				</div>
				<?php
			}


		}
	}

	if ($es_success_msg == TRUE) {
		?>
		<div class="notice notice-success is-dismissible">
			<p><strong>
				<?php echo $es_success; ?>
			</strong></p>
		</div>
		<?php
	}
}

?>

<div class="wrap">
	<h2>
		<?php echo __( 'Subscribers', 'email-subscribers' ); ?>
		<a class="add-new-h2" href="<?php echo ES_ADMINURL; ?>?page=es-view-subscribers&amp;ac=add"><?php echo __( 'Add New Subscriber', 'email-subscribers' ); ?></a>
		<a class="add-new-h2" href="<?php echo ES_ADMINURL; ?>?page=es-view-subscribers&amp;ac=import"><?php echo __( 'Import', 'email-subscribers' ); ?></a>
		<a class="add-new-h2" href="<?php echo ES_ADMINURL; ?>?page=es-view-subscribers&amp;ac=export"><?php echo __( 'Export', 'email-subscribers' ); ?></a>
		<a class="add-new-h2" href="<?php echo ES_ADMINURL; ?>?page=es-view-subscribers&amp;ac=sync"><?php echo __( 'Sync', 'email-subscribers' ); ?></a>
		<a class="add-new-h2" target="_blank" href="<?php echo ES_FAV; ?>"><?php echo __( 'Help', 'email-subscribers' ); ?></a>
		<?php 
			do_action('es_after_action_buttons');
		?>
	</h2>
	<div style="text-align:right;">
		<?php
			$total_subscribers = es_cls_dbquery::es_view_subscriber_count(0);
			$active_subscribers = es_cls_dbquery::es_active_subscribers();
			echo '<span>'.__( 'Total Subscribers: ', 'email-subscribers' ).'</span><span class="es_total_subscribers">'.$total_subscribers.'</span>';
			echo '<br>';
			echo sprintf(__( 'Active Subscribers: %s', 'email-subscribers' ), $active_subscribers );
		?>
	</div>
	<div class="tool-box">
		<form name="frm_es_display" method="post" onsubmit="return _es_bulkaction()">
			<?php
			$offset = 0;
			$limit = 500;

			if ( $search_count == 0 ) {
				$limit = 29999;
			}

			if ( $search_count > 1 ) {
				$offset = $search_count;
			}

			if ( $search_count == 2001 ) {
				$limit = 2000;
			} elseif ( $search_count == 4001 ) {
				$limit = 4000;
			} elseif ( $search_count == 6001 ) {
				$limit = 6000;
			}

			$myData = array();
			$myData = es_cls_dbquery::es_view_subscribers_details(0, $search_sts, $offset, $limit, $search_group);

		    //Columns for Subscribers Dashboard
		    $es_subscribers_col = array();
		    $es_subscribers_col['email'] = __( 'Email Address', 'email-subscribers' );
		    $es_subscribers_col['name'] = __( 'Name', 'email-subscribers' );
		    $es_subscribers_col['status'] =  __( 'Status', 'email-subscribers' );
		    $es_subscribers_col['group'] = __( 'Group', 'email-subscribers' );
		    $es_subscribers_col['date'] = __( 'Signup Date & Time<br>(Y-M-D H:I:S)', 'email-subscribers' );
		    $es_subscribers_col['action'] = __( 'Action', 'email-subscribers' );
		    $es_subscribers_col = apply_filters('es_subscribers_col', $es_subscribers_col);
			?>

			<div class="tablenav">
				<span style="text-align:left;">
					<select name="bulk_action" id="bulk_action" onchange="return _es_action_visible(this.value)">
						<option value=""><?php echo __( 'Bulk Actions', 'email-subscribers' ); ?></option>
						<option value="delete"><?php echo __( 'Delete', 'email-subscribers' ); ?></option>
						<option value="resend"><?php echo __( 'Resend Confirmation', 'email-subscribers' ); ?></option>
						<option value="groupupdate"><?php echo __( 'Update Subscribers Group', 'email-subscribers' ); ?></option>
						<option value="updatestatus"><?php echo __( 'Update Subscribers Status', 'email-subscribers' ); ?></option>
					</select>
					<select name="es_email_group" id="es_email_group" disabled="disabled">
						<option value=''><?php echo __( 'Select Group', 'email-subscribers' ); ?></option>
						<?php
						$groups = array();
						$groups = es_cls_dbquery::es_view_subscriber_group();
						if(count($groups) > 0) {
							$i = 1;
							foreach ($groups as $group) {
								?><option value='<?php echo $group["es_email_group"]; ?>'>
									<?php echo $group["es_email_group"]; ?>
								</option><?php
							}
						}
						?>
					</select>
					<select name="es_update_status" id="es_update_status" disabled="disabled">
						<option value=""><?php echo __( 'Select Status', 'email-subscribers' ); ?></option>
						<option value="Confirmed"><?php echo __( 'Confirmed', 'email-subscribers' ); ?></option>
						<option value="Unconfirmed"><?php echo __( 'Unconfirmed', 'email-subscribers' ); ?></option>
						<option value="Unsubscribed"><?php echo __( 'Unsubscribed', 'email-subscribers' ); ?></option>
						<option value="Single Opt In"><?php echo __( 'Single Opt In', 'email-subscribers' ); ?></option>
						<?php
							do_action('es_after_dropdown_status');
						?>
					</select>
					<input type="submit" value="<?php echo __( 'Apply', 'email-subscribers' ); ?>" class="button action" id="doaction" name="doaction">
				</span>
				<?php 
					do_action('es_after_bulk_action');
				?>
				<span style="float:right;">
					<select name="search_group_action" id="search_group_action" onchange="return _es_search_group_action(this.value)">
						<option value=""><?php echo __( 'All Groups', 'email-subscribers' ); ?></option>
							<?php
								$groups = array();
								$groups = es_cls_dbquery::es_view_subscriber_group();
								if(count($groups) > 0) {
									$i = 1;
									foreach ($groups as $group) {
										?>
										<option value="<?php echo esc_html(stripslashes($group["es_email_group"])); ?>" <?php if(stripslashes($search_group) == $group["es_email_group"]) { echo 'selected="selected"' ; } ?>>
											<?php echo stripslashes($group["es_email_group"]); ?>
										</option>
										<?php
									}
								}
							?>
					</select>
					<select name="search_sts_action" id="search_sts_action" onchange="return _es_search_sts_action(this.value)">
						<option value=""><?php echo __( 'All Status', 'email-subscribers' ); ?></option>
						<option value="Confirmed" <?php if($search_sts=='Confirmed') { echo 'selected="selected"' ; } ?>><?php echo __( 'Confirmed', 'email-subscribers' ); ?></option>
						<option value="Unconfirmed" <?php if($search_sts=='Unconfirmed') { echo 'selected="selected"' ; } ?>><?php echo __( 'Unconfirmed', 'email-subscribers' ); ?></option>
						<option value="Unsubscribed" <?php if($search_sts=='Unsubscribed') { echo 'selected="selected"' ; } ?>><?php echo __( 'Unsubscribed', 'email-subscribers' ); ?></option>
						<option value="Single Opt In" <?php if($search_sts=='Single Opt In') { echo 'selected="selected"' ; } ?>><?php echo __( 'Single Opt In', 'email-subscribers' ); ?></option>
						<?php
						do_action('es_after_dropdown_status');
						?>
									
					</select>
					<select name="search_count_action" id="search_count_action" onchange="return _es_search_count_action(this.value)">
						<option value="1" <?php if($search_count=='1') { echo 'selected="selected"' ; } ?>><?php echo __( '1 to 500 emails', 'email-subscribers' ); ?></option>
						<option value="501" <?php if($search_count=='501') { echo 'selected="selected"' ; } ?>><?php echo __( '501 to 1000', 'email-subscribers' ); ?></option>
						<option value="1001" <?php if($search_count=='1001') { echo 'selected="selected"' ; } ?>><?php echo __( '1001 to 1500', 'email-subscribers' ); ?></option>
						<option value="1501" <?php if($search_count=='1501') { echo 'selected="selected"' ; } ?>><?php echo __( '1501 to 2000', 'email-subscribers' ); ?></option>
						<option value="2001" <?php if($search_count=='2001') { echo 'selected="selected"' ; } ?>><?php echo __( '2001 to 4000', 'email-subscribers' ); ?></option>
						<option value="4001" <?php if($search_count=='4001') { echo 'selected="selected"' ; } ?>><?php echo __( '4001 to 6000', 'email-subscribers' ); ?></option>
						<option value="6001" <?php if($search_count=='6001') { echo 'selected="selected"' ; } ?>><?php echo __( '6001 to 10000', 'email-subscribers' ); ?></option>
						<option value="0" <?php if($search_count=='0') { echo 'selected="selected"' ; } ?>><?php echo __( 'Display All', 'email-subscribers' );?></option>
					</select>
				</span>
			</div>

			<table width="100%" class="widefat" id="straymanage">
				<thead>
					<tr>
						<th scope="col" class="check-column" style="padding: 17px 2px;">
							<input type="checkbox" name="es_checkall" id="es_checkall" onClick="_es_checkall('frm_es_display', 'chk_delete[]', this.checked);" />
						</th>
						<?php 
						foreach ($es_subscribers_col as $key => $name) {
						?>
							<th scope="col"><?php echo $name ?></th>
						<?php
						}
						?>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th scope="col" class="check-column" style="padding: 17px 2px;">
							<input type="checkbox" name="es_checkall" id="es_checkall" onClick="_es_checkall('frm_es_display', 'chk_delete[]', this.checked);" />
						</th>
						<?php 
						foreach ($es_subscribers_col as $key => $name) {
						?>
							<th scope="col"><?php echo $name ?></th>
						<?php
						}
						?>
					</tr>
				</tfoot>
				<tbody>
					<?php
						$i = 0;
						$displayisthere = FALSE;
						$es_data_to_display = array();
						if(count($myData) > 0) {
							foreach ($myData as $data) {
								$es_col_data['es_email_id'] = stripslashes($data['es_email_id']);
								$es_col_data['es_email_mail'] = stripslashes($data['es_email_mail']);
								$es_col_data['es_email_name'] = stripslashes($data['es_email_name']);
								$es_col_data['es_email_status'] = es_cls_common::es_disp_status($data['es_email_status']); 
								$es_col_data['es_email_group'] = stripslashes($data['es_email_group']); 
								$es_col_data['es_email_created'] = get_date_from_gmt($data['es_email_created'],'Y-m-d H:i:s');
								$es_resend_link = ($data['es_email_status'] != 'Confirmed' && $data['es_email_status'] != 'Single Opt In' ) ? "<span class=edit>| <a onClick=javascript:_es_resend(".$data['es_email_id'].") href=javascript:void(0);>".__( "Resend Confirmation", 'email-subscribers' )."</a> </span>" : '' ;
								$es_col_data['es_quick_actions'] = "<div>
																		<span class=edit>
																			<a href=".ES_ADMINURL."?page=es-view-subscribers&amp;ac=edit&amp;did=".$data['es_email_id'].">
																				". __( 'Edit', 'email-subscribers' ) ."
																			</a> |
																		</span>
																		<span class=trash>
																			<a onClick=javascript:_es_delete(".$data["es_email_id"].") href=javascript:void(0);>
																				". __( 'Delete', 'email-subscribers' )."
																			</a>
																		</span>" 
																		.$es_resend_link.
																		"
																	</div>";
								$res = apply_filters('es_subscribers_col_data', $es_col_data, $data);
								$es_data_to_display[] = $res;

							}
							if ($offset == 0) {
								$i = 1;
							} else {
								$i = $offset;
							}
							foreach ($es_data_to_display as $data) {
								?>
								<tr class="<?php if ($i&1) { echo'alternate'; } else { echo ''; } ?>">
									<td align="left"><input name="chk_delete[]" id="chk_delete[]" type="checkbox" value="<?php echo $data['es_email_id'] ?>" /></td>
								<?php 
								unset($data['es_email_id']);
									foreach ($data as $key => $value) {
										?>
										<td><?php echo $value; ?></td>
										<?php
									}
								?>
								</tr>
								<?php
								$i = $i+1;
							}
						} else {
							?>
							<tr>
								<td colspan="7" align="center"><?php echo __( 'No records available.', 'email-subscribers' ); ?></td>
							</tr>
							<?php
						}
						?>
				</tbody>
			</table>
			<?php wp_nonce_field('es_form_show'); ?>
			<input type="hidden" name="frm_es_display" id="frm_es_display" value="yes"/>
			<input type="hidden" name="frm_es_bulkaction" id="frm_es_bulkaction" value=""/>
			<input type="hidden" name="searchquery_sts" id="searchquery_sts" value="<?php echo $search_sts; ?>" />
			<input type="hidden" name="searchquery_cnt" id="searchquery_cnt" value="<?php echo $search_count; ?>" />
			<input type="hidden" name="searchquery_group" id="searchquery_group" value="<?php echo $search_group; ?>" />
			<?php $nonce = wp_create_nonce( 'subscriber-nonce' ); ?>
			<input type="hidden" name="wp_create_nonce" id="wp_create_nonce" value="<?php echo $nonce; ?>"/>
		</form>
	</div>
</div>