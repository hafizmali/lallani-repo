<?php 
 if( get_option('es_offer_bfcm_done_2018_email_subscribers') == 'no' ) return;
?>
<style type="text/css">
.es_offer{
    width: 70%;
    margin: 0 auto;
    text-align: center;
    padding-top: 1.2em;
}
</style>
<div class="es_offer">
    <a target="_blank" href="?dismiss_admin_notice=1&option_name=es_offer_bfcm_done_2018"><img src="<?php echo  ES_URL ?>/images/ig-offer.png"  /></a>
</div>